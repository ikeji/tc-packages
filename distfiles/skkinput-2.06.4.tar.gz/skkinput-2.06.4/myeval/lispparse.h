#if !defined(parse_h)
#define parse_h

#include "kanji.h"

#define MAX_NEST_LEVEL	(32)

enum { 
  TYPE_CONSLIST_STRING = 0, TYPE_CONSLIST_CONSPAIR, TYPE_CONSLIST_ARRAY,
} ;

struct consnode {
  int type ;
  union {
    struct conslist *next ;
    struct myChar *string ;
  } value ;
} ;

/*
 * ���Ϥ˻Ȥ���¤�Ρ�
 */
struct conslist {
  struct consnode left ;
  struct consnode right ;
} ;

/*
 * �ץ��ȥ����������
 */
void skip_space( struct myChar **string ) ;
void free_conslist( struct conslist *top ) ;
struct conslist *string2conslist( struct myChar **string ) ;
void print_conslist( struct conslist *node ) ;
struct myChar *convert_quote( struct myChar *string ) ;
struct conslist *copy_conspair( struct conslist *top ) ;
int delete_comment_string( struct myChar *buffer ) ;

#endif
