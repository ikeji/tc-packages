/* # skkinput (Simple Kana-Kanji Input)
 * WmcloseShellP.h
 * This file is part of skkinput.
 * Copyright (C) 1997
 * Takashi SAKAMOTO (sakamoto@yajima.kuis.kyoto-u.ac.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#if !defined(WmcloseShellP_h)
#define WmcloseShellP_h

#include <X11/ShellP.h>
#include "WmcloseShell.h"

typedef struct {
  XtCallbackList wmclosecallback ;
  XtCallbackList destroycallback ;
  Window probeWindow ;
} WmcloseShellPart ;

/* �դ뤤�󤹤��󤹡� */
typedef struct _WmcloseShellRec {
  CorePart		core ;
  CompositePart		composite ;
  ShellPart 		shell ;
  WMShellPart		wm ;
  VendorShellPart	vendor ;
  TransientShellPart	transient ;	
  WmcloseShellPart	wmclose ;
} WmcloseShellRec ;

/* New fields for the My widget class record */
typedef struct {
  int dummy ;
} WmcloseShellClassPart ;

/* �դ뤯�餹�� */
typedef struct _WmcloseClassRec {
  CoreClassPart			core_class ;
  CompositeClassPart		composite_class ;
  ShellClassPart		shell_class ;
  WMShellClassPart   		wm_shell_class ;
  VendorShellClassPart 		vendor_shell_class ;
  TransientShellClassPart 	transient_shell_class ;
  WmcloseShellClassPart		wmclose_shell_class ;
} WmcloseShellClassRec ;

/* ���餹�ݤ��󤿡� */
extern WmcloseShellClassRec	wmcloseShellClassRec ;

#endif
