/* # skkinput (Simple Kana-Kanji Input)
 * CliMsgP.h --- Private defines for ClientMessageWidgetClass
 * This file is part of skkinput.
 * Copyright (C) 1997
 * Takashi SAKAMOTO (sakamoto@yajima.kuis.kyoto-u.ac.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#if !defined(CliMsgP_h)
#define CliMsgP_h

#include "CliMsg.h"

typedef struct {
  /* ������λ��˸ƽФ���륳����Хå��ؿ�����Ͽ���Ƥ������ȡ� */
  XtCallbackList clientMessageCallback ;
  XtCallbackList destroyCallback ;
} CliMsgPart ;

typedef struct _CliMsgRec {
  CorePart	core ;
  CliMsgPart	cliMsg ;
} CliMsgRec ;

/* New fields for the My widget class record */
typedef struct {
  int dummy ;
} CliMsgClassPart ;

typedef struct _CliMsgClassRec {
  CoreClassPart		core_class ;
  CliMsgClassPart	cliMsg_class ;
} CliMsgClassRec ;

extern CliMsgClassRec cliMsgClassRec ;

#endif
