/* # skkinput (Simple Kana-Kanji Input)
 * resrcs.h --- define X resources
 * This file is part of skkinput.
 * Copyright (C) 1997
 * Takashi SAKAMOTO (sakamoto@yajima.kuis.kyoto-u.ac.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifndef resrcs_h
#define resrcs_h

/* ¿ʬɬ�פʥѥ�᡼��������� CoreWidget �����äƤ�����Ρ�

 ̾��                ���饹             ��              ̵���������
 ----                ------             --              ------------
 background	     Background		pixel		White
 border		     BorderColor	pixel		Black
 borderWidth	     BorderWidth	int		1
 foreground	     Foreground		Pixel		Black
 height		     Height		int		120
 mappedWhenManaged   MappedWhenManaged	Boolean		True
 reverseVideo	     ReverseVideo	Boolean		False
 width		     Width		int		120
 x		     Position		int		0
 y		     Position		int		0
*/

#define XtNkanjiFont		"kanjiFont"
#define XtNtextNotify		"textNotify"
#define XtNfixNotify		"fixNotify"
#define XtNendNotify		"endNotify"
#define XtNkeybackNotify	"keybackNotify"
#define XtNgetfocusNotify	"getfocusNotify"
#define XtNunusedEventNotify	"unusedEventNotify"

#define XtNcompatibleCloseSkkinputKey	"compatibleCloseSkkinputKey"
#define XtCCompatibleCloseSkkinputKey	"CompatibleCloseSkkinputKey"

#define XtNchangeMinibufferFont	"changeMinibufferFont"
#define XtCChangeMinibufferFont	"ChangeMinibufferFont"

#define XtNeggLikeNewline	"eggLikeNewline"
#define XtCEggLikeNewline	"EggLikeNewline"
#define XtNchatAdapter		"chatAdapter"
#define XtCChatAdapter		"ChatAdapter"
#define XtNinitPosition		"initPosition"
#define XtCInitPosition		"InitPosition"
#define XtNjisyoDirty		"jisyoDirty"
#define XtCJisyoDirty		"JisyoDirty"
#define XtNclearMinibuffer	"clearMinibuffer"
#define XtCClearMinibuffer	"ClearMinibuffer"

#define XtNconversionAttribute		"conversionAttribute"
#define XtCConversionAttribute		"ConversionAttribute"

#define XtNdestroyNotify	"destroyNotify"

#define XtNdestroyWindowEvent	"destroyWindowEvent"
#define XtCDestroyWindowEvent	"DestroyWindowEvent"

#define XtNconversionHistory	"conversionHistory"
#define XtCConversionHistory	"ConversionHistory"

#define XtNmwidth		"minibuffer_width"
#define XtCMwidth		"Minibuffer_width"

#define XtNclientWindow		"client_window"
#define XtCClientWindow		"Client_window"

#define XtNsetFocus		"set_focus"
#define XtCSetFocus		"Set_focus"
#define XtNunsetFocus		"unset_focus"
#define XtCUnsetFocus		"Unset_focus"

#define XtNsetupInputWindowNotify	"setupInputWindowNotify"
#define XtNserverCloseNotify		"serverCloseNotify"

#define XtNprobeWindow		"probeWindow"
#define XtCProbeWindow		"ProbeWindow"

#define XtNoverTheSpotLikeInput	"overTheSpotLikeInput"
#define XtCOverTheSpotLikeInput	"OverTheSpotLikeInput"

#define XtNconversionStartKey	"conversionStartKey"
#define XtCConversionStartKey	"ConversionStartKey"

#define XtNsupportedLocales	"supportedLocales"
#define XtCSupportedLocales	"SupportedLocales"

#define XtNshiftHaTugiDeYukou	"shiftHaTugiDeYukou"
#define XtCShiftHaTugiDeYukou	"ShiftHaTugiDeYukou"

#define XtNcontrolHaTugiDeYukou	"controlHaTugiDeYukou"
#define XtCControlHaTugiDeYukou	"ControlHaTugiDeYukou"

#define XtNfontset		"fontSet"
#define XtCFontset		"FontSet"
#define XtNmfontset		"minibufferFontSet"

#define XtNsouthCursor		"southCursor"
#define XtCSouthCursor		"SouthCursor"

#define XtNmodeshell_geometry	"modeshell_geometry"
#define XtCModeShell_Geometry	"ModeShell_Geometry"

#if !defined (XtNpreeditStartCallback)
#define	XtNpreeditStartCallback	"preeditStartCallback"
#endif
#if !defined (XtNpreeditDrawCallback)
#define	XtNpreeditDrawCallback	"preeditDrawCallback"
#endif
#if !defined (XtNpreeditCaretCallback)
#define	XtNpreeditCaretCallback	"preeditCaretCallback"
#endif
#if !defined (XtNpreeditDoneCallback)
#define	XtNpreeditDoneCallback	"preeditDoneCallback"
#endif
#if !defined (XtNstatusStartCallback)
#define	XtNstatusStartCallback	"statusStartCallback"
#endif
#if !defined (XtNstatusDrawCallback)
#define	XtNstatusDrawCallback	"statusDrawCallback"
#endif
#if !defined (XtNstatusDoneCallback)
#define	XtNstatusDoneCallback	"statusDoneCallback"
#endif

#endif
