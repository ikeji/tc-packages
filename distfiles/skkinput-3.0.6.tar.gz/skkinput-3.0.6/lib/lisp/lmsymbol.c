/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lmachinep.h"

/*========================================================================*
 *	private functions
 */

/*	symbol-to-symbol �� wrapper��
 *--
 *	last-command-char, last-command-event �Τ褦��Ʊ������ư���褦�ʤ�Τ�
 *	�б����뤿��� wrapper �Ǥ��롣�����lisp machine ���̤�����Ǥ��롣
 */
static inline TLispEntity*
lispMachine_getRealSymbol (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispBind**	pSym2SymTbl	= pLM->m_apSymbol2SymbolTable ;
	register Boolean		f ;
	TLispBind*				pBind ;
	TLispEntity*			pEntNewSymbol ;

	f	= lispBindTable_SearchEntry (pLispMgr, pSym2SymTbl, SIZE_LISP_BIND_TABLE, pEntSymbol, &pBind) ;
	if (TSUCCEEDED (f) && pBind != NULL) {
		if (TSUCCEEDED (lispBind_GetValue (pBind, &pEntNewSymbol)) &&
			pEntNewSymbol != NULL)
			return	pEntNewSymbol ;
	}
	return	pEntSymbol ;
}

/*
 *[��ǽ]
 *	buffer-local-variable ���ͤ����ꤹ�롣
 *[����]
 *	Lisp ��̿��� buffer-local-variable ������ؤ��ơ��ͤ򥻥åȤ���
 *	��Τ����뤫�ɤ�����ʬ����ʤ���Ĵ����­���⤷��ʤ�����
 */
static inline Boolean
lispMachine_setCurrentBufferLocalSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntBuffer ;

	assert (pLM        != NULL) ;
	assert (pEntSymbol != NULL) ;
	assert (pEntValue  != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr   != NULL) ;
	pEntBuffer	= pLM->m_pCurBuffer ;

	/*	���ιԤϰ��Ū�ʤ�Τ���������*/
	if (pEntBuffer == NULL)
		return	False ;

	return	lispBuffer_SetSymbolValue (pLispMgr, pEntBuffer, pEntSymbol, pEntValue) ;
}

/*
 *[��ǽ]
 *	Lisp Machine �� Local �ʥ���ܥ���ͤ򥻥åȤ��롣
 */
static inline Boolean
lispMachine_setGlobalSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispBind**	pVarTbl ;
	TLispBind*	pBind ;

	assert (pLM             != NULL) ;
	assert (pLM->m_pLispMgr != NULL) ;
	assert (pEntSymbol      != NULL) ;

	pVarTbl		= pLM->m_apVariableTable ;
	if (TFAILED (lispBindTable_SearchEntry (pLispMgr, pVarTbl, SIZE_LISP_BIND_TABLE, pEntSymbol, &pBind)) ||
		pBind == NULL) {
		if (TFAILED (lispBindTable_MakeEntry (pLispMgr, pVarTbl, SIZE_LISP_BIND_TABLE, pEntSymbol, &pBind)))
			return	False ;
	}
	lispBind_SetValue (pLispMgr, pBind, pEntValue) ;
	return	True ;
}

static inline Boolean
lispMachine_getBufferLocalSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntBuffer,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register Boolean			fRetval ;
	TLispEntity*	pEntRetval ;

	assert (pLM         != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (pEntBuffer  != NULL) ;
	assert (ppEntReturn != NULL) ;

	fRetval	= lispBuffer_GetSymbolValue (pLispMgr, pEntBuffer, pEntTarget, &pEntRetval) ;
	if (TFAILED (fRetval) ||
		pEntRetval == NULL ||
		TSUCCEEDED (lispEntity_Emptyp (pLispMgr, pEntRetval)))
		return	False ;
	*ppEntReturn	= pEntRetval ;
	return	True ;
}

/*
 *[��ǽ]
 *	Lisp Machine �� local �ʥ���ܥ�(�ѿ�)��������롣����ܥ��̾����
 *	Lisp �� Entity ��Ϳ���롣
 */
Boolean
lispMachine_MakeSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pSymbol,
	register TLispBind**	ppBindReturn)
{
	assert (pLM      != NULL) ;
	assert (pSymbol  != NULL) ;

	return	lispBindTable_MakeEntry (pLM->m_pLispMgr, pLM->m_apVariableTable, NELEMENTS (pLM->m_apVariableTable), pSymbol, ppBindReturn) ;
}

/*
 *[��ǽ]
 *	Lisp Machine �� Local �ʥ���ܥ�(�ѿ�)��������롣����ܥ��̾����
 *	Char ʸ�����Ϳ���롣
 */
Boolean
lispMachine_MakeSymbolValueWithName (
	register TLispMachine*	pLM,
	register const Char*	pName,
	register const int		nName,
	register TLispBind**	ppBindReturn)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntSymbol ;
	assert (pLM      != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	False ;
	return	lispBindTable_MakeEntry (pLispMgr, pLM->m_apVariableTable, NELEMENTS (pLM->m_apVariableTable), pEntSymbol, ppBindReturn) ;
}

/*
 *[��ǽ]
 *	Local �ʤ�Τ�����֤˥���ܥ�(�ѿ�)��¸�ߤ��뤫��ǧ���ơ����դ��ä�
 *	����ܥ���Ф����ͤ򥻥åȤ��롣
 *	Global �ʥ���ܥ�ޤ�����¸�ߤ��ʤ��ä����ˤϡ�Global ����ܥ���
 *	�������ͤ򥻥åȤ��롣
 */
Boolean
lispMachine_SetCurrentSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	assert (pLM        != NULL) ;
	assert (pEntSymbol != NULL) ;
	assert (pEntValue  != NULL) ;

	pEntSymbol	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
	return	(lispMachine_setCurrentBufferLocalSymbolValue (pLM, pEntSymbol, pEntValue) ||
			 lispMachine_setGlobalSymbolValue      (pLM, pEntSymbol, pEntValue)) ;
}

/*
 *[��ǽ]
 *	buffer-local-variable ���ͤ����ꤹ�롣
 *[����]
 *	Lisp ��̿��� buffer-local-variable ������ؤ��ơ��ͤ򥻥åȤ���
 *	��Τ����뤫�ɤ�����ʬ����ʤ���Ĵ����­���⤷��ʤ�����
 */
Boolean
lispMachine_SetCurrentBufferLocalSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntBuffer ;

	assert (pLM        != NULL) ;
	assert (pEntSymbol != NULL) ;
	assert (pEntValue  != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr   != NULL) ;
	pEntBuffer	= pLM->m_pCurBuffer ;

	/*	���ιԤϰ��Ū�ʤ�Τ���������*/
	if (pEntBuffer == NULL)
		return	False ;

	pEntSymbol	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
	return	lispBuffer_SetSymbolValue (pLispMgr, pEntBuffer, pEntSymbol, pEntValue) ;
}

/*
 *[��ǽ]
 *	Lisp Machine �� Local �ʥ���ܥ���ͤ򥻥åȤ��롣
 */
Boolean
lispMachine_SetGlobalSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	assert (pLM             != NULL) ;
	assert (pEntSymbol      != NULL) ;

	pEntSymbol	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
	return	lispMachine_setGlobalSymbolValue (pLM, pEntSymbol, pEntValue) ;
}

/*
 *[��ǽ]
 *	buffer-local-variable ���ͤ򥻥åȤ��롣����ܥ�� Char ʸ�����Ϳ���롣
 */
Boolean
lispMachine_SetCurrentBufferLocalSymbolValueWithName (
	register TLispMachine*	pLM,
	register const Char*	pName,
	register const int		nName,
	register TLispEntity*	pEntValue)
{
	assert (pLM       != NULL) ;
	assert (pName     != NULL && nName > 0) ;
	assert (pEntValue != NULL) ;

	/*	���ιԤϰ��Ū�ʤ�Τ���������*/
	if (pLM->m_pCurBuffer == NULL)
		return	False ;

	return	lispBuffer_SetSymbolValueWithName (pLM->m_pLispMgr, pLM->m_pCurBuffer, pName, nName, pEntValue) ;
}

/*
 *[��ǽ]
 *	Lisp Machine �� local �ʥ���ܥ���ͤ򥻥åȤ��롣����ܥ�� Char ʸ����
 *	�ǻ��ꤹ�롣
 */
Boolean
lispMachine_SetGlobalSymbolValueWithName (
	register TLispMachine*	pLM,
	register const Char*	pName,
	register const int		nName,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;

	assert (pLM             != NULL) ;
	assert (pLM->m_pLispMgr != NULL) ;
	assert (pName           != NULL && nName > 0) ;
	assert (pEntValue       != NULL) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	False ;

	pEntSymbol	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
	return	lispMachine_setGlobalSymbolValue (pLM, pEntSymbol, pEntValue) ;
}

/*
 *[��ǽ]
 *	Symbol ̾�Ǥ�äơ�Symbol ���ͤ������Ƥ롣Local �ʤ�Τ��� Global ��
 *	��ΤؤȽ��֤� Symbol ���ͤ�������Ƥ��Ƥ��뤫���Ƥ�����
 *	�ǽ�Ū��ï�⤽�� Symbol ���ͤ�������ƤƤ��ʤ���С�Global �� Symbol 
 *	Value �Ȥ����ͤ�������Ƥ��뤳�Ȥˤʤ롣
 *	Buffer Local �� Machine Local �� Symbol ���ͤ������Ƥ������ˤϡ���
 *	�����Ѱդ��Ƥ���ɬ�פ����롣
 */
Boolean
lispMachine_SetCurrentSymbolValueWithName (
	register TLispMachine*	pLM,
	register const Char*	pName,
	register const int		nName,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;

	assert (pLM       != NULL) ;
	assert (pName     != NULL && nName > 0) ;
	assert (pEntValue != NULL) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	False ;

	pEntSymbol	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
	return	(lispMachine_setCurrentBufferLocalSymbolValue (pLM, pEntSymbol, pEntValue) ||
			 lispMachine_setGlobalSymbolValue      (pLM, pEntSymbol, pEntValue)) ;
}

Boolean
lispMachine_SetCurrentSymbolValueWithNameA (
	register TLispMachine*	pLM,
	register const char*	pName,
	register const int		nName,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;

	assert (pLM       != NULL) ;
	assert (pName     != NULL && nName > 0) ;
	assert (pEntValue != NULL) ;

	if (TFAILED (lispMgr_InternSymbolA (pLispMgr, pName, nName, &pEntSymbol)))
		return	False ;

	pEntSymbol	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
	return	(lispMachine_setCurrentBufferLocalSymbolValue (pLM, pEntSymbol, pEntValue) ||
			 lispMachine_setGlobalSymbolValue      (pLM, pEntSymbol, pEntValue)) ;
}

/*
 *[��ǽ]
 *	����ܥ�˳�����Ƥ��Ƥ����ͤ����롣local �ʤ�Τ�����֤˸�������
 *	���դ��ä��Ȥ����ǡ����Υ���ܥ���ͤ����롣����ܥ�� entity �ǻ���
 *	���롣
 *[����]
 *	������entity �Υ����פ�����ܥ�Ǥʤ���Х��顼�ˤʤ롣
 */
Boolean
lispMachine_GetCurrentSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	assert (pLM         != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (ppEntReturn != NULL) ;

	return	(lispMachine_GetCurrentBufferLocalSymbolValue (pLM, pEntTarget, ppEntReturn) ||
			 lispMachine_GetGlobalSymbolValue (pLM, pEntTarget, ppEntReturn)) ;
}

Boolean
lispMachine_GetCurrentBufferLocalSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	pEntTarget	= lispMachine_getRealSymbol (pLM, pEntTarget) ;
	return	lispMachine_getBufferLocalSymbolValue (pLM, pLM->m_pCurBuffer, pEntTarget, ppEntReturn) ;
}

Boolean
lispMachine_GetGlobalSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntSymbol,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*	pEntTarget ;

	assert (pLM             != NULL) ;
	assert (pLispMgr        != NULL) ;
	assert (pEntSymbol      != NULL) ;
	assert (ppEntReturn     != NULL) ;

	while (pLM != NULL) {
		pEntTarget	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
		if (TSUCCEEDED (lispBindTable_GetEntryValue (pLispMgr, pLM->m_apVariableTable, NELEMENTS (pLM->m_apVariableTable), pEntTarget, ppEntReturn)))
			return	True ;
		pLM	= pLM->m_pMacParent ;
	}
	return	False ;
}

Boolean
lispMachine_GetSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntBuffer,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	return	(lispMachine_GetBufferLocalSymbolValue (pLM, pEntBuffer, pEntTarget, ppEntReturn) ||
			 lispMachine_GetGlobalSymbolValue (pLM, pEntTarget, ppEntReturn)) ;
}

Boolean
lispMachine_GetBufferLocalSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntBuffer,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	assert (pLM         != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (pEntBuffer  != NULL) ;
	assert (ppEntReturn != NULL) ;

	pEntTarget	= lispMachine_getRealSymbol (pLM, pEntTarget) ;
	return	lispMachine_getBufferLocalSymbolValue (pLM, pEntBuffer, pEntTarget, ppEntReturn) ;
}

Boolean
lispMachine_GetCurrentSymbolValueWithName (
	register TLispMachine*			pLM,
	register const Char*			pName,
	register const int				nName,
	register TLispEntity** const	ppReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;

	assert (pLM      != NULL) ;
	assert (ppReturn != NULL) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	False ;

	return	(lispMachine_GetCurrentBufferLocalSymbolValue (pLM, pEntSymbol, ppReturn) ||
			 lispMachine_GetGlobalSymbolValue (pLM, pEntSymbol, ppReturn)) ;
}

Boolean
lispMachine_GetCurrentBufferLocalSymbolValueWithName (
	register TLispMachine*			pLM,
	register const Char*			pName,
	register const int				nName,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*	pEntBuffer	= pLM->m_pCurBuffer ;
	TLispEntity*			pEntSymbol ;
	register TLispEntity*	pEntTarget ;

	assert (pLM      != NULL) ;
	assert (pName    != NULL && nName > 0) ;
	assert (ppEntReturn != NULL) ;

	if (pEntBuffer == NULL)
		return	False ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	False ;
	pEntTarget	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
	return	lispMachine_getBufferLocalSymbolValue (pLM, pEntBuffer, pEntTarget, ppEntReturn) ;
}

Boolean
lispMachine_GetGlobalSymbolValueWithName (
	register TLispMachine*			pLM,
	register const Char*			pName,
	register const int				nName,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*			pEntSymbol ;
	register TLispEntity*	pEntTarget ;

	assert (pLM             != NULL) ;
	assert (pLM->m_pLispMgr != NULL) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	False ;

	while (pLM != NULL) {
		pEntTarget	= lispMachine_getRealSymbol (pLM, pEntSymbol) ;
		if (TSUCCEEDED (lispBindTable_GetEntryValue (pLispMgr, pLM->m_apVariableTable, NELEMENTS (pLM->m_apVariableTable), pEntTarget, ppEntReturn)))
			return	True ;
		pLM	= pLM->m_pMacParent ;
	}
	return	False ;
}

/*	function, property �ˤ� symbol -> symbol �� map �ϱƶ����ʤ����Ȥ��롣
 */
Boolean
lispMachine_SetSymbolFunctionValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntSymbol,
	register TLispEntity*			pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispBind**	ppBindTbl ;
	TLispBind*	pBind ;

	assert (pLM         != NULL) ;
	assert (pEntSymbol  != NULL) ;
	assert (pEntValue   != NULL) ;

	ppBindTbl	= pLM->m_apFunctionTable ;
	if (TFAILED (lispBindTable_SearchEntry (pLispMgr, ppBindTbl, NELEMENTS (pLM->m_apFunctionTable), pEntSymbol, &pBind)) ||
		pBind == NULL) {
		if (TFAILED (lispBindTable_MakeEntry (pLispMgr, ppBindTbl, NELEMENTS (pLM->m_apFunctionTable), pEntSymbol, &pBind)))
			return	False ;
	}
	lispBind_SetValue (pLispMgr, pBind, pEntValue) ;
	return	True ;
}

Boolean
lispMachine_GetSymbolFunctionValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	const LMCMDINFO*	pProcInfo ;

	assert (pLM         != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (ppEntReturn != NULL) ;

	while (pLM != NULL) {
		if (TSUCCEEDED (lispBindTable_GetEntryValue (pLispMgr, pLM->m_apFunctionTable, NELEMENTS (pLM->m_apFunctionTable), pEntTarget, ppEntReturn)))
			return	True ;
		pLM	= pLM->m_pMacParent ;
	}
	/*	builtin function �ˤʤ���Ĵ�٤롣*/
	if (TFAILED (lispMachine_SearchBuiltinFunction (pLispMgr, pEntTarget, &pProcInfo)) ||
		pProcInfo == NULL) 
		return	False ;

	return	lispMgr_CreateSubr (pLispMgr, pProcInfo, ppEntReturn) ;
}

Boolean
lispMachine_GetFinalSymbolFunctionValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntTarget,
	register TLispEntity**	ppEntReturn)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntValue ;
	register int	nCount		= MAX_NEST_COUNT ;

	assert (pLM != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (ppEntReturn != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	while (TSUCCEEDED (lispEntity_Symbolp (pLispMgr, pEntTarget)) &&
		   nCount -- > 0) {
		if (TFAILED (lispMachine_GetSymbolFunctionValue (pLM, pEntTarget, &pEntValue))) {
#if 1
			fprintf (stderr, "void function: ") ;
			lispEntity_Print (pLispMgr, pEntTarget) ;
#endif
		}
		pEntTarget	= pEntValue ;
	}
	if (nCount == 0)
		return	False ;
	*ppEntReturn	= pEntValue ;
	return	True ;
}

/*
 */
Boolean
lispMachine_SetSymbolProperty (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntSymbol,
	register TLispEntity* 			pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispBind**	pBindTbl ;
	TLispBind*	pBind ;

	assert (pLM         != NULL) ;
	assert (pEntSymbol  != NULL) ;
	assert (pEntValue   != NULL) ;

	pBindTbl	= pLM->m_apPropertyTable ;
	if (TFAILED (lispBindTable_SearchEntry (pLispMgr, pBindTbl, NELEMENTS (pLM->m_apPropertyTable), pEntSymbol, &pBind)) ||
		pBind == NULL) {
		if (TFAILED (lispBindTable_MakeEntry (pLispMgr, pBindTbl, NELEMENTS (pLM->m_apPropertyTable), pEntSymbol, &pBind)))
			return	False ;
	}
	lispBind_SetValue (pLispMgr, pBind, pEntValue) ;
	return	True ;
}

Boolean
lispMachine_GetSymbolProperty (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntSymbol,
	register TLispEntity**			ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;

	assert (pLM         != NULL) ;
	assert (pEntSymbol  != NULL) ;
	assert (ppEntReturn != NULL) ;

	while (pLM != NULL) {
		if (TSUCCEEDED (lispBindTable_GetEntryValue (pLispMgr, pLM->m_apPropertyTable, NELEMENTS (pLM->m_apPropertyTable), pEntSymbol, ppEntReturn)))
			return	True ;
		pLM	= pLM->m_pMacParent ;
	}
	return	False ;
}

