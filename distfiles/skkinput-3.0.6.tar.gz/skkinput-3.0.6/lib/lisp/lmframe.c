/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "AfxWin.h"
#include <stdio.h>
#include "lispmgrp.h"
#include "TFontSet.h"
#include "lmachinep.h"
#include "TTerminal.h"
#include "TFrame.h"

static	Boolean	lispMachine_updateFrame				(TLispMachine*, TLispEntity*) ;
static	Boolean	lispMachine_resizeNormalFrame		(TLispMachine*, TLispEntity*, const XRectangle*) ;
static	Boolean	lispMachine_activeFramep			(TLispMachine*, TLispEntity*) ;


Boolean
lispMachine_UpdateCurrentFrame (
	register TLispMachine*	pLM)
{
	assert (pLM != NULL) ;
	assert (pLM->m_pCurFrame != NULL) ;

	return	lispMachine_updateFrame (pLM, pLM->m_pCurFrame) ;
}

Boolean
lispMachine_UpdateAllFrame (
	register TLispMachine*	pLM)
{
	TLispEntity*	pEntFrame ;
	assert (pLM != NULL) ;

	pEntFrame	= pLM->m_lstFrame ;
	if (pEntFrame != NULL) {
		do {
			lispMachine_updateFrame (pLM, pEntFrame) ;
			lispFrame_GetNext (pEntFrame, &pEntFrame) ;
		}	while (pEntFrame != pLM->m_lstFrame) ;
	}
	return	True ;
}

void
lispMachine_ScheduleUpdateAllFrame (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntFrame ;
	TLispEntity*			pEntNextFrame ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	pEntFrame	= pLM->m_lstFrame ;

	if (pEntFrame != NULL) {
		do {
			lispFrame_ScheduleUpdate (pLispMgr, pEntFrame) ;
			lispFrame_GetNext (pEntFrame, &pEntNextFrame) ;
			pEntFrame	= pEntNextFrame ;
		}	while (pEntFrame != pLM->m_lstFrame) ;
	}
	return ;
}

Boolean
lispMachine_ResizeFrame (
	register TLispMachine*		pLM,
	register TLispEntity*		pEntFrame,
	register const XRectangle*	pRC)
{
	Widget	wgTerminal ;

	assert (pLM != NULL) ;
	assert (pEntFrame != NULL) ;

	if (TFAILED (lispFrame_GetTerminal (pEntFrame, &wgTerminal)))
		return	False ;
	if (TFrame_RectVariablep (wgTerminal)) {
		lispFrame_ScheduleUpdate (pLM->m_pLispMgr, pEntFrame) ;
		return	lispMachine_updateFrame (pLM, pEntFrame) ;
	} else {
		assert (pRC != NULL) ;
		return	lispMachine_resizeNormalFrame (pLM, pEntFrame, pRC) ;
	}
}	

/*	���Ƥ� frame ����֤���󤹤롣
 */
Boolean
lispMachine_EnumFrame (
	register TLispMachine*	pLM,
	register Boolean		(*pProc)(TLispMachine*, TLispEntity*, void*, Boolean*),
	register void*			pCaller)
{
	register TLispEntity*	pEntFrame ;
	Boolean					fContinue ;

	assert (pLM   != NULL) ;
	assert (pProc != NULL) ;

	if (pLM->m_lstFrame == NULL) 
		return	True ;

	fContinue	= True ;
	pEntFrame	= pLM->m_lstFrame ;
	do {
		TLispEntity*	pEntNextFrame ;
		lispFrame_GetNext (pEntFrame, &pEntNextFrame) ;
		if (TFAILED ((pProc)(pLM, pEntFrame, pCaller, &fContinue)))
			return	False ;
		if (TFAILED (fContinue))
			break ;
		pEntFrame	= pEntNextFrame ;
	}	while (pEntFrame != pLM->m_lstFrame) ;
	
	return	True ;
}

/*	Frame �ˤ�ɽ������ʸ�����ʤˤ�ʤ��ơ��ե����������ʤ���о����
 *	�Ĥ����Τ����롣(XUnmapWindow ����ưŪ�˹Ԥ���)
 *
 *	����������Τ�Ƚ��äƤɤ����롩 ���Υե���������ï�����äƤơ�
 *	���ä��Ƥ褤�����Ȥ���������
 */
Boolean
lispMachine_updateFrame (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntFrame)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	Widget					wgTerminal ;
	TLispEntity*			pEntTopWindow ;
	TLispEntity*			pEntWindow ;

	assert (pLispMgr  != NULL) ;
	assert (pEntFrame != NULL) ;
	assert (pEntFrame->m_iType == LISPENTITY_FRAME) ;

	if (TFAILED (lispFrame_GetTerminal (pEntFrame, &wgTerminal)))
		return	False ;
	if (TFAILED (lispFrame_NeedUpdatep (pLispMgr, pEntFrame)))
		return	True ;

	/*	������б����� terminal ��ޤ� clear ���ơ�*/
	TFrame_Clear (wgTerminal) ;

#if defined (DEBUG)
	fprintf (stderr, "updateFrame(%p) Auto(%d), Active(%d) ... ",
			 pEntFrame,
			 TFrame_AutoPopupp (wgTerminal),
			 lispMachine_activeFramep (pLM, pEntFrame)) ;
#endif
	if (!TFrame_AutoPopupp (wgTerminal) ||
		TSUCCEEDED (lispMachine_activeFramep (pLM, pEntFrame))) {
#if defined (DEBUG)
		fprintf (stderr, "yes\n") ;
#endif
		(void) lispFrame_GetTopWindow (pEntFrame, &pEntTopWindow) ;
		assert (pEntTopWindow != NULL) ;

		pEntWindow	= pEntTopWindow ;
		/*	��Ȥ���֤����� (putchar?) ���Ƥ��äơ�*/
		do {
			lispMachine_UpdateWindow (pLM, pEntFrame, pEntWindow) ;
			lispWindow_GetNext (pEntWindow, &pEntWindow) ;
		}	while (pEntWindow != pEntTopWindow) ;

		/*
		 *	Minibuffer Window �� Frame �˴ޤޤ�Ƥ���Ȳ��ꡣ
		 *	lispWindow_Update (pLispMgr, pFrame->m_pEntMinibufWindow) ;
		 */
#if defined (DEBUG)
	} else {
		fprintf (stderr, "no\n") ;
#endif
	}

	TFrame_Flush (wgTerminal) ;
	return	True ;
}

/*	���̥ե졼��Υ������ѹ����б����롣�������ˤ� Window ���¤Фʤ��Ȳ��ꤹ�롣
 *	OverTheSpot, OffTheSpot �ˤ��б��Ǥ��ʤ���
 */
Boolean
lispMachine_resizeNormalFrame (
	register TLispMachine*		pLM,
	register TLispEntity*		pEntFrame,
	register const XRectangle*	pRC)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*	pEntWindow ;
	TLispEntity*			pEntTopWindow ;
	TLispEntity*			pEntNextWindow ;
	TLispEntity*			pEntMinibufWindow ;
	register Boolean		fMinibufExist, fMoveFocus ;
	register int			nWidth, nHeight ;
	register int			y, nFontHeight, nDelta, nWindow ;
	register int			nPrevHeight ;
	register TFontSet*		pFontSet ;
	XRectangle				rect, newRect ;
	Widget					wgTerminal ;
	
	assert (pLispMgr != NULL) ;
	assert (pEntFrame != NULL) ;

	nWidth	= pRC->width ;
	nHeight	= pRC->height ;
#if defined (DEBUG)
	fprintf (stderr, "lispMachine_ResizeNormalFrame (%p, %p, %d, %d)\n",
			 pLispMgr, pEntFrame, nWidth, nHeight) ;
#endif

	(void) lispFrame_GetTopWindow (pEntFrame, &pEntTopWindow) ;
	assert (pEntTopWindow != NULL) ;
	if (TFAILED (lispFrame_GetMinibufferWindow (pEntFrame, &pEntMinibufWindow)))
		pEntMinibufWindow	= NULL ;
	pEntWindow		= pEntTopWindow ;
	assert (pEntWindow != NULL) ;
	nPrevHeight		= 0 ;
	nWindow			= 0 ;
	fMinibufExist	= False ;
	do {
		lispWindow_GetArea (pEntWindow, &rect) ;
		nPrevHeight	+=	rect.height ;
		nWindow		++ ;
		if (pEntWindow == pEntMinibufWindow) 
			fMinibufExist	= True ;
		lispWindow_GetNext (pEntWindow, &pEntNextWindow) ;
		pEntWindow	= pEntNextWindow ;
	}	while (pEntWindow != pEntTopWindow) ;

	/*	�礭�����ѹ�����Ƥ��ʤ���С����⤹��ɬ�פϤʤ���
	 */
	nDelta		= nHeight - nPrevHeight ;
	if (nDelta == 0 && nWidth == rect.width) 
		return	True ;

	/*	Window ��1�Ĥ���¸�ߤ��ʤ���С�����ư�������Ƥ��ɽ����롣
	 */
	if (nWindow == 1) {
		newRect.x		= 0 ;
		newRect.y		= 0 ;
		newRect.width	= nWidth ;
		newRect.height	= nHeight ;
		lispWindow_SetArea (pEntTopWindow, &newRect) ;
		return	lispMachine_updateFrame (pLM, pEntFrame) ;
	}

	/*	Minibuffer Window �δ���ϳ�����
	 */
	if (fMinibufExist)
		nWindow	-- ;

	/*	�ե���Ȥι⤵�����Ƥ�����
	 */
	(void) lispFrame_GetTerminal (pEntFrame, &wgTerminal) ;
	pFontSet	= TFrame_GetFontSet (wgTerminal) ;
	assert (pFontSet != NULL) ;
	nFontHeight	= pFontSet->m_iHeight ;
	assert (nFontHeight >= 1) ;

	/*	Window ��ʣ��������ˤϽ��֤ˡ�
	 */
	pEntWindow	= pEntTopWindow ;
	y			= 0 ;
	fMoveFocus	= False ;
	do {
		lispWindow_GetArea (pEntWindow, &rect) ;
		lispWindow_GetNext (pEntWindow, &pEntNextWindow) ;

		if (pEntWindow == pEntMinibufWindow) {
			newRect.x		= rect.x ;
			newRect.y		= rect.y ;
			newRect.width	= nWidth ;
			newRect.height	= rect.height ;
			lispWindow_SetArea (pEntWindow, &newRect) ;
			y				+= newRect.height ;
		} else {
			/*	Minibuffer Window ������ơ�¾�� Window ��¸�ߤǤ�����ˤϡ�������
			 *	�ʤ�᤮�� Window �Ͼõ��롣
			 */
			if ((rect.height + nDelta) < nFontHeight * 2 && nWindow > 1) {
				nDelta			+= rect.height ;
				/*	���ξä���� Window �� Focus ����äƤ������ˤϡ����� Window
				 *	�� Focus ���ư������ɬ�פ����롣
				 */
				if (TSUCCEEDED (lispWindow_HaveFocusp (pEntWindow)))
					fMoveFocus	= True ;
				lispFrame_RemoveWindow (pLispMgr, pEntFrame, pEntWindow) ;
				nWindow			-- ;
			} else {
				newRect.x		= rect.x ;
				newRect.y		= y ;
				newRect.width	= nWidth ;
				newRect.height	= rect.height + nDelta ;
				lispWindow_SetArea (pEntWindow, &newRect) ;
				nDelta			= 0 ;
				y				+= newRect.height ;

				/*	�ե��������ΰ�ư��ɬ�פ�����������
				 */
				if (TSUCCEEDED (fMoveFocus)) {
					lispWindow_SetFocus (pEntWindow, True) ;
					fMoveFocus	= False ;
				}
			}
		}
#if defined (DEBUG)
		fprintf (stderr, "Window: (%d, %d, %d, %d), FontHeight: %d\n",
				 newRect.x, newRect.y, newRect.width, newRect.height, nFontHeight) ;
#endif
		pEntWindow		= pEntNextWindow ;
	}	while (pEntWindow != pEntTopWindow) ;

	return	lispMachine_updateFrame (pLM, pEntFrame) ;
}

/*	Active Frame ���ɤ���������å����롣
 */
Boolean
lispMachine_activeFramep (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntFrame)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*			pEntTopWindow ;
	TLispEntity*			pEntWindow ;
	TLispEntity*			pEntMsg ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr  != NULL) ;
	assert (pEntFrame != NULL) ;
	assert (pEntFrame->m_iType == LISPENTITY_FRAME) ;

	/*	Current Frame �ʤ�����ɽ������ʤ���Фʤ�ʤ���
	 */
	if (pEntFrame == pLM->m_pCurFrame)
		return	True ;

	/*	�����Ǥʤ��Τʤ顢����ɽ�������٤���Τ���äƤ��뤫
	 *	�����å����롣��å���������äƤ���Ȥ����Хåե�����
	 *	�Ǥʤ��Ȥ���
	 */
	(void) lispFrame_GetTopWindow (pEntFrame, &pEntTopWindow) ;
	assert (pEntTopWindow != NULL) ;
	pEntWindow	= pEntTopWindow ;
	do {
		if (TSUCCEEDED (lispWindow_GetMessage (pEntWindow, &pEntMsg)) &&
			TFAILED (lispEntity_Nullp (pLispMgr, pEntMsg))) {
			const Char*		pString ;
			int				nString ;

			if (TSUCCEEDED (lispEntity_GetStringValue (pLispMgr, pEntMsg, &pString, &nString)) &&
				nString > 0) 
				return	True ;
#if defined (DEBUG)
			fprintf (stderr, "lispMachine_activeFramep (): window(%p): no message\n",
					 pEntWindow) ;
#endif
		} else {
			TLispEntity*		pEntBuffer ;
			TBufStringMarker	mk ;
			int					nLength ;

			if (TSUCCEEDED (lispWindow_GetBuffer (pEntWindow, &pEntBuffer)) &&
				TSUCCEEDED (lispBuffer_GetFullString (pLispMgr, pEntBuffer, &mk, &nLength)) &&
				nLength > 0)
				return	True ;
#if defined (DEBUG)
			fprintf (stderr, "lispMachine_activeFramep (): window(%p): no buffer text\n",
					 pEntWindow) ;
#endif
		}
		lispWindow_GetNext (pEntWindow, &pEntWindow) ;
	}	while (pEntWindow != pEntTopWindow) ;

	return	False ;
}

