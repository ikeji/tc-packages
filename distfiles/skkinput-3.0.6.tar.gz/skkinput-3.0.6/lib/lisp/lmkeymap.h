#if !defined (lmkeymap_h)
#define	lmkeymap_h

#include "lmachinep.h"

TLispEntity*	lispMachine_GetGlobalMap		(TLispMachine*) ;
Boolean			lispMachine_EnumMinorModeMaps	(TLispMachine*, Boolean (*)(TLispMachine*, TLispEntity*, void*, Boolean*), void*) ;

#endif

