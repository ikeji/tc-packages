/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#if !defined (TerminalP_h)

#include "Char.h"
#include "TFontSet.h"
#include "varbuffer.h"
#include <X11/IntrinsicP.h>
#include <X11/CoreP.h>
#include <X11/StringDefs.h>
#include "TTerminal.h"

typedef struct {
	int				m_nIndex ;		/*	�ƥ�������Ƭ��������Ʋ�ʸ������*/
	int				m_nLength ;		/*	��ʸ������Τ���*/
	int				m_nSize ;
	int				m_nPrev ;
	int				m_nNext ;
}	TTermLineInfo ;

typedef struct tagTTerminalPart {
	Window			m_wndParent ;
	Pixel			m_pxlFore ;
	/*Pixel			m_pxlBack ;*/
	String			m_strFontSet ;	/* ������Ȱ������Τ�������� interface */
	TFontSet		m_FontSet ;
	GC				m_gc ;
	Boolean			m_fReverseVideo ;

	int				m_iRow ;
	int				m_iColumn ;
	Boolean			m_fRev ;

	/*	���β���Ĺ�Хåե��δ��ܤ��礭�������礭�᤮��Ȼפ���*/
	TVarbuffer		m_vbCurText ;
	TVarbuffer		m_vbCurLineInfo ;
	TVarbuffer		m_vbReqText ;
	TVarbuffer		m_vbReqLineInfo ;
	int				m_nReqTailLineIndex ;
}	TTerminalPart ;

typedef struct tagTTerminalRec {
	CorePart		core ;
	TTerminalPart	tterminal ;
}	TTerminalRec ;

typedef struct {
	int				dummy ;
}	TTerminalClassPart ;

typedef struct tagTerminalClassRec {
	CoreClassPart		core_class ;
	TTerminalClassPart	tterminal_class ;
}	TTerminalClassRec ;

extern	TTerminalClassRec	tterminalClassRec ;

#endif

