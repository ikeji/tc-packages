/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#if !defined (TOnTheSpotWindow_h)
#define	TOnTheSpotWindow_h

#include "TFrame.h"
#include <X11/Xlib.h>

/*	OnTheSpot �Ѵ��ˤ����������ΰ�ι����Τ���˥��饤����Ȥ�����
 *	����
 */
typedef struct tagTOnTheSpotDrawArg {
	int				m_nCaret ;
	int				m_nChgFirst ;
	int				m_nChgLength ;
	const Char*		m_pText ;
	int				m_nText ;
	XIMFeedback*	m_pAttribute ;
	int				m_nAttribute ;
}	TOnTheSpotDrawArg ;

#if !defined (XtNpreeditStartCallback)
#define	XtNpreeditStartCallback	"preeditStartCallback"
#endif
#if !defined (XtNpreeditDrawCallback)
#define	XtNpreeditDrawCallback	"preeditDrawCallback"
#endif
#if !defined (XtNpreeditCaretCallback)
#define	XtNpreeditCaretCallback	"preeditCaretCallback"
#endif
#if !defined (XtNpreeditDoneCallback)
#define	XtNpreeditDoneCallback	"preeditDoneCallback"
#endif
#if !defined (XtNstatusStartCallback)
#define	XtNstatusStartCallback	"statusStartCallback"
#endif
#if !defined (XtNstatusDrawCallback)
#define	XtNstatusDrawCallback	"statusDrawCallback"
#endif
#if !defined (XtNstatusDoneCallback)
#define	XtNstatusDoneCallback	"statusDoneCallback"
#endif
#if !defined (XtNminibufFrame)
#define	XtNminibufFrame	"minibufFrame"
#endif
#if !defined (XtCMinibufFrame)
#define	XtCMinibufFrame	"MinibufFrame"
#endif

typedef struct tagTOnTheSpotWindowRec*		TOnTheSpotWindowWidget ;
typedef struct tagTOnTheSpotWindowClassRec*	TOnTheSpotWindowWidgetClass ;

extern	WidgetClass		tonTheSpotWindowWidgetClass ;

Widget	TOnTheSpotWindowFrame_Create (Widget, ArgList, Cardinal) ;

#endif
