/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#if !defined (TFrame_h)
#define	TFrame_h

#include "Char.h"

struct tagTConversionAttribute ;

#if !defined (XtNlispClient)
#define	XtNlispClient			"lispClient"
#endif
#if !defined (XtCLispClient)
#define	XtCLispClient			"LispClient"
#endif
#if !defined (XtNlispFrameObject)
#define	XtNlispFrameObject		"lispFrameObject"
#endif
#if !defined (XtCLispFrameObject)
#define	XtCLispFrameObject		"LispFrameObject"
#endif
#if !defined (XtNkeypressCallback)
#define	XtNkeyPressCallback		"keyPressCallback"
#endif
#if !defined (XtNconfigureCallback)
#define	XtNconfigureCallback	"configureCallback"
#endif
#if !defined (XtNdestroyCallback)
#define	XtNdestroyCallback		"destroyCallback"
#endif

typedef struct tagTFrameRec*		TFrameWidget ;
typedef struct tagTFrameClassRec*	TFrameWidgetClass ;

extern	WidgetClass		tframeWidgetClass ;

/*	Prototypes  */
void*	TFrame_GetClient			(Widget) ;
int		TFrame_GetRect				(Widget, XRectangle*) ;
void	TFrame_Activate				(Widget, Boolean) ;
void*	TFrame_GetFontSet			(Widget) ;
Boolean	TFrame_GetLineSpacing		(Widget, int*) ;
void*	TFrame_GetLispFrameObject	(Widget) ;
void	TFrame_SetAttribute			(Widget, const struct tagTConversionAttribute*) ;
Boolean	TFrame_Putchar				(Widget, const Char) ;
Boolean	TFrame_Puts					(Widget, const Char*, int) ;
void	TFrame_Rev					(Widget, Boolean) ;
void	TFrame_Clear				(Widget) ;
void	TFrame_Flush				(Widget) ;
Boolean	TFrame_RectVariablep		(Widget) ;
Boolean	TFrame_HaveExternModeline	(Widget) ;
Boolean	TFrame_SetModeline			(Widget, const Char*, int) ;
Boolean	TFrame_AutoPopupp			(Widget) ;
void	TFrame_SetCaret				(Widget) ;

#endif

