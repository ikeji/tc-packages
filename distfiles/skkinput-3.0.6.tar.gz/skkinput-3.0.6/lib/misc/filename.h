/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#if !defined (filename_h)
#define	filename_h

#include "varbuffer.h"
#include "Char.h"

/*
 */
Boolean	ConvertInternalFileName2SystemFileName (char*, int, const Char*, int) ;
Boolean	ExpandFileName			(TVarbuffer*, const Char*, int, const Char*, int) ;
Boolean	GetFileNameNondirectory	(const Char*, int, const Char**, int*) ;
Boolean	GetFileDirectoryAnsi	(const char*, int, const char**, int*) ;

#endif

